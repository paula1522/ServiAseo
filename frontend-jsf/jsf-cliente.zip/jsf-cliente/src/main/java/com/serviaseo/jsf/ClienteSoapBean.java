﻿package com.serviaseo.jsf;

import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@Named
@ViewScoped
public class ClienteSoapBean implements Serializable {
    private String numeroDocumento;
    private boolean existe;
    private String nombres;
    private String apellidos;
    private String email;
    private String mensaje;

    public void verificar() {
        try {
            URL url = new URL("http://localhost:7001/soap");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
            conn.setDoOutput(true);

            String soapRequest = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:serv=\"http://serviaseo.com/soap\">"
                    + "<soapenv:Header/>"
                    + "<soapenv:Body>"
                    + "<serv:verificarClienteRequest>"
                    + "<serv:numeroDocumento>" + numeroDocumento + "</serv:numeroDocumento>"
                    + "</serv:verificarClienteRequest>"
                    + "</soapenv:Body>"
                    + "</soapenv:Envelope>";

            try(OutputStream os = conn.getOutputStream()) {
                os.write(soapRequest.getBytes("UTF-8"));
                os.flush();
            }

            int responseCode = conn.getResponseCode();
            if(responseCode == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while((line = br.readLine()) != null) sb.append(line);
                String response = sb.toString();
                existe = response.contains("<existe>true</existe>");
                if(existe) {
                    nombres = extractTag(response, "nombres");
                    apellidos = extractTag(response, "apellidos");
                    email = extractTag(response, "email");
                    mensaje = "Cliente encontrado";
                } else {
                    mensaje = "Cliente no encontrado";
                    limpiar();
                }
            } else {
                mensaje = "Error al comunicarse con el servicio SOAP";
            }
        } catch(Exception e) {
            mensaje = "Error: " + e.getMessage();
        }
    }

    private String extractTag(String xml, String tag) {
        String open = "<" + tag + ">";
        String close = "</" + tag + ">";
        int start = xml.indexOf(open);
        if(start != -1) {
            start += open.length();
            int end = xml.indexOf(close, start);
            if(end != -1) return xml.substring(start, end);
        }
        return "";
    }

    private void limpiar() {
        nombres = apellidos = email = "";
    }

    public String getNumeroDocumento() { return numeroDocumento; }
    public void setNumeroDocumento(String numeroDocumento) { this.numeroDocumento = numeroDocumento; }
    public boolean isExiste() { return existe; }
    public String getNombres() { return nombres; }
    public String getApellidos() { return apellidos; }
    public String getEmail() { return email; }
    public String getMensaje() { return mensaje; }
}
